# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vr', 'vr.entities', 'vr.image', 'vr.windows']

package_data = \
{'': ['*']}

install_requires = \
['mss>=6.1.0,<7.0.0', 'opencv-python>=4.5.3,<5.0.0', 'pydantic>=1.8.2,<2.0.0']

entry_points = \
{'console_scripts': ['simpledimple = vr.main:main']}

setup_kwargs = {
    'name': 'vr',
    'version': '0.1.0',
    'description': '',
    'long_description': 'VR ERROR CHECKER\n',
    'author': 'Чичко Александра Алексеевна',
    'author_email': 'tiredsosha@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
