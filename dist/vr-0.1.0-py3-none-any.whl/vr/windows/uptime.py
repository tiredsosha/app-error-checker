import os
import time


def get_uptime(num_word: int):
    os.system(
        'nircmd exec hide powershell "Get-ComputerInfo | select "OsUptime" | Out-File -FilePath uptime.txt"'
    )
    time.sleep(10)
    uptime = readfile('uptime.txt', num_word)
    return uptime


def readfile(name: str, number: int):
    with open(name) as gfile:
        gdata = gfile.read().strip().split()
        status = gdata[number].encode('ascii').decode('ascii')
        return status
