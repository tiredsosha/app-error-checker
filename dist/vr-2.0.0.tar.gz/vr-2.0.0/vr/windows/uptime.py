import os
import time


def get_uptime():
    up = os.popen('uptime -p').read()[:-1]
    return up
